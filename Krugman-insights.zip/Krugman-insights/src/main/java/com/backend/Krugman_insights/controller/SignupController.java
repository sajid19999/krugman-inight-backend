package com.backend.Krugman_insights.controller;

import com.backend.Krugman_insights.model.User;
import com.backend.Krugman_insights.repository.UserRepository;
import com.backend.Krugman_insights.service.OTPService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/signup")
public class SignupController {
    @Autowired
    private OTPService otpService;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/verify-email")
    public String verifyEmail(@RequestParam String email) {
        Optional<User> existingUser = userRepository.findByEmail(email);
        if (existingUser.isPresent()) {
            return "Email already registered!";
        }
        return otpService.generateAndSendOTP(email);
    }

    @PostMapping("/verify-otp")
    public boolean verifyOtp(@RequestParam String email, @RequestParam String otp) {
        return otpService.validateOTP(email, otp);
    }

    @PostMapping("/create-account")
    public ResponseEntity<Map<String, String>> createAccount(@RequestBody User user) {
        Optional<User> existingUser = userRepository.findByEmail(user.getEmail());
        if (existingUser.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("message", "Email already registered!"));
        }
        user.setVerified(true);
        userRepository.save(user);
        return ResponseEntity.ok(Map.of("message", "Account created successfully!"));
    }

}
