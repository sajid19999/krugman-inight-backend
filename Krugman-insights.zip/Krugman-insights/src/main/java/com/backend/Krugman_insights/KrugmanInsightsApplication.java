package com.backend.Krugman_insights;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KrugmanInsightsApplication {

	public static void main(String[] args) {
		SpringApplication.run(KrugmanInsightsApplication.class, args);
	}

}
