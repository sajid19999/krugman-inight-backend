package com.backend.Krugman_insights.service;
import com.backend.Krugman_insights.model.OTP;
import com.backend.Krugman_insights.repository.OTPRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.Random;
@Service

public class OTPService {



        @Autowired
        private OTPRepository otpRepository;

        @Autowired
        private JavaMailSender mailSender;

        // Generate and send OTP
        public String generateAndSendOTP(String email) {
            String otp = String.valueOf(new Random().nextInt(900000) + 100000);
            OTP otpEntity = new OTP();
            otpEntity.setEmail(email);
            otpEntity.setOtp(otp);
            otpEntity.setExpiryTime(System.currentTimeMillis() + 300000); // OTP valid for 5 minutes

            otpRepository.save(otpEntity);

            sendEmail(email, otp);
            return "OTP sent successfully!";
        }

        // Validate OTP
        public boolean validateOTP(String email, String otp) {
            return otpRepository.findByEmail(email)
                    .filter(o -> o.getOtp().equals(otp) && o.getExpiryTime() > System.currentTimeMillis())
                    .isPresent();
        }

        // Send OTP via email
        private void sendEmail(String email, String otp) {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(email);
            message.setSubject("Your OTP Code");
            message.setText("Your OTP is: " + otp);
            mailSender.send(message);
        }

}
